import { useEffect, useMemo, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import Swal from 'sweetalert2';

import { toggleChatSidebar } from '../redux/action';
import getUserData from '../hooks/getUserData';
import { getRoomData } from '../hooks/getRoom';

import RoomErrorBoundary from './components/RoomErrorBoundary';
import LoadingScreen from './components/LoadingScreen';
import RoomStyles from './components/RoomStyles';
import TopMeetingBar from './components/TopMeetingBar';
import StatusBanner from './components/StatusBanner';
import VideoStage from './components/VideoStage';
import ControlDock from './components/ControlDock';
import ReactionPicker from './components/ReactionPicker';
import SubtitlesOverlay from './components/SubtitlesOverlay';
import ParticipantsPanel from './components/ParticipantsPanel';
import ChatPanel from './components/ChatPanel';
import DeviceSettingsModal from './components/DeviceSettingsModal';
import useMeetingTimer from './hooks/useMeetingTimer';
import useRoomController from './hooks/useRoomController';

const RoomMain = ({ uId }) => {
  const { id } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const timer = useMeetingTimer();

  const mediaPrefs = useSelector((state) => state.mediaPrefs);
  const isChatOpen = useSelector((state) => state.toggleChatSidebar);

  const { rooms } = getRoomData() || {};

  const [currUserData, setCurrUserData] = useState(null);
  const [userLoading, setUserLoading] = useState(true);
  const [currentRoomData, setCurrentRoomData] = useState(null);
  const [isHost, setIsHost] = useState(false);

  useEffect(() => {
    let cancelled = false;

    getUserData(uId)
      .then((data) => {
        if (!cancelled) setCurrUserData(data);
      })
      .catch(() => {})
      .finally(() => {
        if (!cancelled) setUserLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [uId]);

  useEffect(() => {
    const roomData = rooms?.find((entry) => entry.id === id || entry._id === id);

    setCurrentRoomData(roomData || null);

    if (roomData && uId) {
      setIsHost(roomData.ownerUid === uId || roomData.hostId === uId);
    }
  }, [id, rooms, uId]);

  const room = useRoomController({
    id,
    uId,
    currUserData,
    isHost,
    mediaPrefs,
    isChatOpen,
    navigate,
    dispatch,
    toggleChatSidebar,
  });

  useEffect(() => {
    const handler = () => {
      window.history.pushState(null, '', window.location.href);
      room.showLeaveModal();
    };

    window.history.pushState(null, '', window.location.href);
    window.addEventListener('popstate', handler);

    return () => {
      window.removeEventListener('popstate', handler);
    };
  }, [room.showLeaveModal]);

  const copyLink = () => {
    navigator.clipboard?.writeText(window.location.href);

    Swal.fire({
      toast: true,
      icon: 'success',
      title: 'Meeting link copied',
      position: 'top-end',
      timer: 1500,
      showConfirmButton: false,
      background: '#0f172a',
      color: '#fff',
    });
  };

  const commonTileProps = useMemo(() => ({
    isHost,
    menuOpenFor: room.isSettingOn,
    onToggleMenu: room.setIsSettingOn,
    onForceMute: room.forceMuteUser,
    onKick: room.kickUser,
    onOpenProfile: (uid) => {
      if (uid) {
        window.open(`/profile/${uid}`, '_blank', 'noopener,noreferrer');
      }
    },
    onFullscreen: room.setFullscreenId,
    onPin: (uid) => {
      room.setPinnedId((prev) => (prev === uid ? null : uid));
    },
  }), [
    isHost,
    room.isSettingOn,
    room.setIsSettingOn,
    room.forceMuteUser,
    room.kickUser,
    room.setFullscreenId,
    room.setPinnedId,
  ]);

  const isPageLoading = userLoading || !currentRoomData;

  if (isPageLoading) {
    return <LoadingScreen roomTitle={currentRoomData?.Title || 'Meeting Room'} />;
  }

  return (
    <RoomErrorBoundary>
      <RoomStyles />

      <div className="relative flex h-[100dvh] w-screen overflow-hidden bg-[#050713] text-white">
        {/* Ambient background */}
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div className="absolute -left-40 -top-40 h-[30rem] w-[30rem] rounded-full bg-blue-600/15 blur-[140px]" />
          <div className="absolute -bottom-44 -right-44 h-[34rem] w-[34rem] rounded-full bg-violet-600/15 blur-[150px]" />
          <div className="absolute left-1/2 top-1/2 h-[22rem] w-[22rem] -translate-x-1/2 -translate-y-1/2 rounded-full bg-cyan-400/8 blur-[120px]" />
        </div>

        <div className="relative z-10 flex h-full min-w-0 flex-1 flex-col">
          <TopMeetingBar
            title={currentRoomData?.Title || 'Meeting Room'}
            roomId={id}
            timer={timer}
            isHost={isHost}
            totalCount={room.totalCount}
            user={currUserData}
            raisedHand={room.raisedHand}
            connectionState={room.connectionState}
            onCopyLink={copyLink}
            onToggleParticipants={() => room.setShowParticipants((value) => !value)}
            onOpenDeviceSettings={() => room.setShowDeviceSettings(true)}
          />

          <StatusBanner
            isScreenSharing={room.isScreenSharing}
            mediaError={room.mediaError}
            onStopScreenShare={room.stopScreenShare}
            onRetryMedia={() => room.initLocalMedia()}
          />

          {/* 
            Layout fix:
            - main = video area
            - ChatPanel = separate side column
            - ControlDock is inside main, so it overlays only video, not chat.
          */}
          <div className="relative flex min-h-0 flex-1 overflow-hidden">
            <main
              className={`
                relative min-w-0 flex-1 overflow-hidden transition-all duration-300
                ${isChatOpen ? 'md:flex-none md:w-[calc(100%-min(380px,32vw))]' : ''}
              `}
            >
              <VideoStage
                localTile={room.localTile}
                participants={room.participantsArray}
                totalCount={room.totalCount}
                activeScreenShare={room.activeScreenShare}
                localScreenStream={room.localScreenStream}
                remoteScreenStreams={room.remoteScreenStreams}
                activeSpeakerUid={room.activeSpeakerUid}
                fullscreenId={room.fullscreenId}
                pinnedId={room.pinnedId}
                commonTileProps={commonTileProps}
                onExitFullscreen={() => room.setFullscreenId(null)}
              />

              <SubtitlesOverlay lines={room.activeSubtitleLines} />

              <ControlDock
                isAudioEnabled={room.isAudioEnabled}
                isVideoEnabled={room.isVideoEnabled}
                isScreenSharing={room.isScreenSharing}
                showReactionPicker={room.showReactionPicker}
                subtitlesEnabled={room.subtitlesEnabled}
                raisedHand={room.raisedHand}
                isChatOpen={isChatOpen}
                unreadCount={room.unreadCount}
                totalCount={room.totalCount}
                onToggleAudio={room.toggleAudio}
                onToggleVideo={room.toggleVideo}
                onToggleScreenShare={room.toggleScreenShare}
                onToggleReactions={() => room.setShowReactionPicker((value) => !value)}
                onToggleRaiseHand={room.toggleRaiseHand}
                onToggleSubtitles={room.toggleSubtitles}
                onToggleParticipants={() => room.setShowParticipants((value) => !value)}
                onToggleChat={room.handleToggleChat}
                onLeave={room.showLeaveModal}
              />

              <ReactionPicker
                show={room.showReactionPicker}
                onReact={room.sendReaction}
              />
            </main>

            <ChatPanel isOpen={isChatOpen} uId={uId} />
          </div>
        </div>

        <ParticipantsPanel
          show={room.showParticipants}
          participants={room.participantsArray}
          currentUser={currUserData}
          isHost={isHost}
          onClose={() => room.setShowParticipants(false)}
          onForceMute={room.forceMuteUser}
          onKick={room.kickUser}
        />

        <DeviceSettingsModal
          show={room.showDeviceSettings}
          devices={room.devices}
          selectedAudioDeviceId={room.selectedAudioDeviceId}
          selectedVideoDeviceId={room.selectedVideoDeviceId}
          onClose={() => room.setShowDeviceSettings(false)}
          onChangeAudioDevice={room.changeAudioDevice}
          onChangeVideoDevice={room.changeVideoDevice}
        />
      </div>
    </RoomErrorBoundary>
  );
};

export default RoomMain;